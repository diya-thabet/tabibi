package com.example.telemed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelemedApplicationTests {

	@Test
	void contextLoads() {
	}

}
